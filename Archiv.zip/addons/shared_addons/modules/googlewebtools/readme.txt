Google Webtools Integration Module - Version 1.0

DESCRIPTION
Allows you to add a Google webtools verification code to the metadata of all your front-end pages. Works with any theme and does not require alterations to themes.

INSTALLING
1. Copy the "googlewebtools" folder over to your add-ons folder in your PyroCMS installation (/addons/<site>/modules/googlewebtools or /addons/shared_addons/modules/googlewebtools)

2. Go to your administration panel and enable the module under the "Add-ons" menu.

The module is now ready for use!

USAGE
You can add your Google Webmaster Tools site verification code in the "Settings" menu under the "Integration" tab.

SUPPORT
Please visit the PyroCMS add-ons page for support, or contact me at Da-Huntha@lostmoment.com.
