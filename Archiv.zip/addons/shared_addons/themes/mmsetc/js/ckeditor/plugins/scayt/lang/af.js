﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'af', {
	about: 'SCAYT info',
	aboutTab: 'Info',
	addWord: 'Voeg woord by',
	allCaps: 'Ignoreer woorde in hoofletters',
	dic_create: 'Skep',
	dic_delete: 'Verwijder',
	dic_field_name: 'Naam van woordeboek',
	dic_info: 'Aanvanklik word die gebruikerswoordeboek in \'n koekie gestoor. Koekies is egter beperk in grootte. Wanneer die gebruikerswoordeboek te groot vir \'n koekie geword het, kan dit op ons bediener gestoor word. Om u persoonlike woordeboek op ons bediener te stoor, gee asb. \'n naam vir u woordeboek. Indien u alreeds \'n gestoorde woordeboek het, tik die naam en kliek op die Herstel knop.',
	dic_rename: 'Hernoem',
	dic_restore: 'Herstel',
	dictionariesTab: 'Woordeboeke',
	disable: 'SCAYT af',
	emptyDic: 'Woordeboeknaam mag nie leeg wees nie.',
	enable: 'SCAYT aan',
	ignore: 'Ignoreer',
	ignoreAll: 'Ignoreer alles',
	ignoreDomainNames: 'Ignoreer domeinname',
	langs: 'Tale',
	languagesTab: 'Tale',
	mixedCase: 'Ignoreer woorde met hoof- en kleinletters',
	mixedWithDigits: 'Ignoreer woorde met syfers',
	moreSuggestions: 'Meer voorstelle',
	opera_title: 'Nie ondersteun deur Opera nie',
	options: 'Opsies',
	optionsTab: 'Opsies',
	title: 'Speltoets terwyl u tik',
	toggle: 'SCAYT wissel aan/af',
	noSuggestions: 'No suggestion'
});
