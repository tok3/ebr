<?php ob_start ("ob_gzhandler");

header("Content-type: text/css; charset: UTF-8"); ?>